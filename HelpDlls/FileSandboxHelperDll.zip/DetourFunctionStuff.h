#pragma once

bool DetourNtFileRoutines();